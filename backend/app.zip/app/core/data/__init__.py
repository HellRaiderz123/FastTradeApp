"""
Data module - Historical data fetching and management
"""

from app.core.data.candles import get_historical_candles

__all__ = ["get_historical_candles"]

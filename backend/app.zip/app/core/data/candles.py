"""
Historical candle data fetching
Supports both real Zerodha data and mock data for backtesting
"""

import logging
import os
import pickle
from datetime import date, datetime, timedelta
from typing import List, Dict, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Cache directory for historical data
CACHE_DIR = Path(__file__).parent.parent.parent.parent / "data_cache"
CACHE_DIR.mkdir(exist_ok=True)


def _save_candles_to_db(symbol: str, candles: List[Dict[str, Any]], interval: str = "15minute"):
    """Save candles to database for live strategy access.
    
    Uses a single bulk query for duplicate detection instead of per-row SELECT.
    """
    try:
        from app.db.models_candles import Candle15m, CandleDaily
        from app.db.session import SessionLocal
        
        if interval not in ["15minute", "daily"]:
            return
        if not candles:
            return
        
        db = SessionLocal()
        try:
            if interval == "15minute":
                # Build timestamps for all candles
                ts_map = {}
                for candle in candles:
                    candle_date = candle.get("date")
                    candle_time = candle.get("time")
                    if not candle_date:
                        continue
                    if candle_time:
                        timestamp = datetime.combine(candle_date, candle_time)
                    else:
                        timestamp = datetime.combine(candle_date, datetime.min.time())
                    ts_map[timestamp] = candle

                if not ts_map:
                    return

                # Single query: check which timestamps already exist
                existing_timestamps = set(
                    row[0] for row in
                    db.query(Candle15m.timestamp)
                    .filter(Candle15m.symbol == symbol, Candle15m.timestamp.in_(list(ts_map.keys())))
                    .all()
                )

                # Bulk insert only new candles
                new_objs = []
                for ts, candle in ts_map.items():
                    if ts not in existing_timestamps:
                        new_objs.append(Candle15m(
                            symbol=symbol,
                            timestamp=ts,
                            open=candle.get("open", 0),
                            high=candle.get("high", 0),
                            low=candle.get("low", 0),
                            close=candle.get("close", 0),
                            volume=candle.get("volume", 0),
                        ))
                if new_objs:
                    db.bulk_save_objects(new_objs)
            else:
                # Daily candles
                date_map = {}
                for candle in candles:
                    candle_date = candle.get("date")
                    if not candle_date:
                        continue
                    date_map[candle_date] = candle

                if not date_map:
                    return

                existing_dates = set(
                    row[0] for row in
                    db.query(CandleDaily.date)
                    .filter(CandleDaily.symbol == symbol, CandleDaily.date.in_(list(date_map.keys())))
                    .all()
                )

                new_objs = []
                for d, candle in date_map.items():
                    if d not in existing_dates:
                        new_objs.append(CandleDaily(
                            symbol=symbol,
                            date=d,
                            open=candle.get("open", 0),
                            high=candle.get("high", 0),
                            low=candle.get("low", 0),
                            close=candle.get("close", 0),
                            volume=candle.get("volume", 0),
                        ))
                if new_objs:
                    db.bulk_save_objects(new_objs)

            db.commit()
            logger.debug(f"✅ Saved candles to database for {symbol}")
        finally:
            db.close()
    except Exception as e:
        logger.debug(f"Failed to save candles to DB: {e}")



def get_historical_candles(
    symbol: str,
    start_date: date,
    end_date: date,
    interval: str = "15minute",
) -> List[Dict[str, Any]]:
    """
    Fetch historical candles for a symbol
    Priority: Cache → Zerodha API → Mock data
    
    Args:
        symbol: Stock symbol (NIFTY, BANKNIFTY, etc.)
        interval: Candle interval (15minute, daily, etc.)
    
    Returns:
        List of candle data dictionaries
    """
    try:
        source = (os.getenv("CANDLES_SOURCE") or "").strip().upper()
        save_to_db = (os.getenv("SAVE_CANDLES_TO_DB", "1").strip() != "0")

        # Optional override for forcing a specific source.
        # Supported values: MOCK, ZERODHA, YFINANCE
        if source == "ZERODHA":
            candles = _fetch_from_zerodha(symbol, start_date, end_date, interval)
            if not candles:
                raise RuntimeError("Zerodha returned no candles")
            _cache_candles(symbol, start_date, end_date, interval, candles)
            return candles

        if source == "YFINANCE":
            candles = _fetch_from_yfinance(symbol, start_date, end_date, interval)
            if not candles:
                raise RuntimeError("Yahoo Finance returned no candles")
            _cache_candles(symbol, start_date, end_date, interval, candles)
            return candles

        if source == "MOCK":
            logger.warning(f"⚠️ Using mock candles for {symbol} (CANDLES_SOURCE=MOCK)")
            candles = _generate_mock_candles(symbol, start_date, end_date, interval)
            logger.info(f"✅ Generated {len(candles)} mock candles for {symbol}")
            if save_to_db:
                _save_candles_to_db(symbol, candles, interval)
            return candles

        # Try cache first
        cached = _get_cached_candles(symbol, start_date, end_date, interval)
        if cached:
            logger.info(f"✅ Loaded {len(cached)} candles from cache for {symbol}")
            return cached
        
        # Try Zerodha API (PRIMARY - real broker data)
        try:
            candles = _fetch_from_zerodha(symbol, start_date, end_date, interval)
            if candles:
                logger.info(f"✅ Fetched {len(candles)} real candles from Zerodha for {symbol}")
                _cache_candles(symbol, start_date, end_date, interval, candles)
                if save_to_db:
                    _save_candles_to_db(symbol, candles, interval)  # Save to DB for live strategy
                return candles
        except Exception as e:
            logger.debug(f"Zerodha fetch failed: {e}")
        
        # Try Yahoo Finance (SECONDARY - free backup)
        try:
            candles = _fetch_from_yfinance(symbol, start_date, end_date, interval)
            if candles:
                logger.info(f"✅ Fetched {len(candles)} candles from Yahoo Finance for {symbol}")
                _cache_candles(symbol, start_date, end_date, interval, candles)
                if save_to_db:
                    _save_candles_to_db(symbol, candles, interval)  # Save to DB for live strategy
                return candles
        except Exception as e:
            logger.debug(f"Yahoo Finance fetch failed: {e}")
        
        # Fall back to mock data
        logger.warning(f"⚠️ Using mock candles for {symbol} (not realistic)")
        candles = _generate_mock_candles(symbol, start_date, end_date, interval)
        logger.info(f"✅ Generated {len(candles)} mock candles for {symbol}")
        if save_to_db:
            _save_candles_to_db(symbol, candles, interval)  # Save to DB for live strategy
        return candles
    
    except Exception as e:
        logger.error(f"❌ Failed to fetch candles: {e}")
        return []


def _get_cached_candles(
    symbol: str,
    start_date: date,
    end_date: date,
    interval: str,
) -> Optional[List[Dict[str, Any]]]:
    """Try to load candles from local cache"""
    try:
        cache_file = CACHE_DIR / f"{symbol}_{interval}_{start_date}_{end_date}.pickle"
        
        if cache_file.exists():
            with open(cache_file, "rb") as f:
                candles = pickle.load(f)
                logger.debug(f"Loaded {len(candles)} candles from cache: {cache_file}")
                return candles
    except Exception as e:
        logger.debug(f"Cache load error: {e}")
    
    return None


def _cache_candles(
    symbol: str,
    start_date: date,
    end_date: date,
    interval: str,
    candles: List[Dict[str, Any]],
) -> None:
    """Cache candles to disk"""
    try:
        cache_file = CACHE_DIR / f"{symbol}_{interval}_{start_date}_{end_date}.pickle"
        
        with open(cache_file, "wb") as f:
            pickle.dump(candles, f)
            logger.debug(f"Cached {len(candles)} candles: {cache_file}")
    except Exception as e:
        logger.warning(f"Cache save error: {e}")


def _fetch_from_yfinance(
    symbol: str,
    start_date: date,
    end_date: date,
    interval: str,
) -> Optional[List[Dict[str, Any]]]:
    """Fetch real historical candles from Yahoo Finance"""
    try:
        import yfinance as yf
        import pandas as pd
        
        # Map symbols to Yahoo Finance tickers for Indian indices
        symbol_map = {
            "NIFTY": "^NSEI",      # Nifty 50
            "BANKNIFTY": "^NSEBANK",  # Bank Nifty
            "FINNIFTY": "^NIFTYIT",   # Nifty IT (closest proxy)
        }
        
        ticker = symbol_map.get(symbol)
        if not ticker:
            logger.debug(f"No Yahoo Finance ticker mapping for {symbol}")
            return None
        
        # Map interval to yfinance format
        interval_map = {
            "15minute": "15m",
            "hourly": "60m",
            "daily": "1d",
        }
        
        yf_interval = interval_map.get(interval, "1d")
        
        logger.debug(f"Fetching {symbol} ({ticker}) from Yahoo Finance: {start_date} to {end_date}")
        
        # Fetch data
        df = yf.download(
            ticker,
            start=start_date,
            end=end_date,
            interval=yf_interval,
            progress=False,
            ignore_tz=True,
        )
        
        if df is None or df.empty:
            logger.debug(f"No data from Yahoo Finance for {ticker}")
            return None
        
        # Reset index to make datetime a column
        if isinstance(df.index, pd.DatetimeIndex):
            df = df.reset_index()
        
        # Convert to standard format
        candles = []
        for _, row in df.iterrows():
            # Extract date and time
            timestamp = row.get("Date") or row.get("Datetime")
            if pd.isna(timestamp):
                continue
            
            if hasattr(timestamp, "date"):
                row_date = timestamp.date()
                row_time = timestamp.time() if hasattr(timestamp, "time") else None
            else:
                row_date = timestamp
                row_time = None
            
            candle = {
                "date": row_date,
                "time": row_time,
                "open": float(row.get("Open", 0)),
                "high": float(row.get("High", 0)),
                "low": float(row.get("Low", 0)),
                "close": float(row.get("Close", 0)),
                "volume": int(row.get("Volume", 0)),
                "interval": interval,
            }
            
            if candle["close"] > 0:  # Only add valid candles
                candles.append(candle)
        
        logger.debug(f"✅ Fetched {len(candles)} real candles from Yahoo Finance for {symbol}")
        return candles if candles else None
        
    except ImportError:
        logger.debug("yfinance not installed, skipping Yahoo Finance fetch")
        return None
    except Exception as e:
        logger.debug(f"Yahoo Finance fetch error: {e}")
        return None


def _fetch_from_zerodha(
    symbol: str,
    start_date: date,
    end_date: date,
    interval: str,
) -> Optional[List[Dict[str, Any]]]:
    """Fetch real historical candles from Zerodha"""
    try:
        from app.core.broker.zerodha.client import get_kite_client
        
        kite = get_kite_client()
        
        # Map symbols to Zerodha instrument tokens
        token_map = {
            "NIFTY": 256265,      # NIFTY 50
            "BANKNIFTY": 256138,  # BANK NIFTY
            "FINNIFTY": 257801,   # FIN NIFTY
            "MIDCPNIFTY": 276561, # MID CAP NIFTY
        }
        
        token = token_map.get(symbol)
        if not token:
            logger.debug(f"No Zerodha token for {symbol}")
            return None
        
        # Map interval to Zerodha format
        interval_map = {
            "15minute": "15minute",
            "hourly": "60minute",
            "daily": "day",
        }
        
        zerodha_interval = interval_map.get(interval, "15minute")
        
        logger.info(f"📡 Fetching {symbol} from Zerodha: {start_date} to {end_date} ({zerodha_interval})")
        
        # Fetch historical data
        # Kite expects datetimes for intraday intervals.
        from_dt = datetime.combine(start_date, datetime.min.time())
        to_dt = datetime.combine(end_date, datetime.max.time())

        history = kite.historical_data(
            instrument_token=token,
            from_date=from_dt,
            to_date=to_dt,
            interval=zerodha_interval,
        )
        
        if not history:
            logger.debug(f"No historical data from Zerodha for {symbol}")
            return None
        
        # Convert to standard format
        candles = []
        for candle in history:
            try:
                # Extract date/time
                timestamp = candle.get("date")
                if hasattr(timestamp, "date"):
                    row_date = timestamp.date()
                    row_time = timestamp.time() if hasattr(timestamp, "time") else None
                else:
                    row_date = timestamp
                    row_time = None
                
                converted = {
                    "date": row_date,
                    "time": row_time,
                    "open": float(candle.get("open", 0)),
                    "high": float(candle.get("high", 0)),
                    "low": float(candle.get("low", 0)),
                    "close": float(candle.get("close", 0)),
                    "volume": int(candle.get("volume", 0)),
                    "interval": interval,
                }
                
                if converted["close"] > 0:
                    candles.append(converted)
            except Exception as e:
                logger.debug(f"Error converting Zerodha candle: {e}")
                continue
        
        logger.info(f"✅ Fetched {len(candles)} candles from Zerodha for {symbol}")
        return candles if candles else None
        
    except RuntimeError as e:
        logger.debug(f"Zerodha credentials not set: {e}")
        return None
    except Exception as e:
        logger.debug(f"Zerodha fetch error: {e}")
        return None


def _generate_mock_candles(
    symbol: str,
    start_date: date,
    end_date: date,
    interval: str,
) -> List[Dict[str, Any]]:
    """
    Generate mock candle data for testing
    TODO: Replace with actual broker API calls
    """
    candles = []
    current_date = datetime.combine(start_date, datetime.min.time())
    end_datetime = datetime.combine(end_date, datetime.max.time())
    
    # Determine increment based on interval
    if interval == "15minute":
        increment = timedelta(minutes=15)
    elif interval == "hourly":
        increment = timedelta(hours=1)
    elif interval == "daily":
        increment = timedelta(days=1)
    else:
        increment = timedelta(minutes=15)
    
    # Base price for the symbol
    base_prices = {
        "NIFTY": 20000,
        "BANKNIFTY": 45000,
        "FINNIFTY": 22000,
    }
    base_price = base_prices.get(symbol, 20000)
    
    import random
    import math
    
    # Generate realistic candles with some randomness
    price = base_price
    
    while current_date <= end_datetime:
        # Skip weekends
        if current_date.weekday() >= 5:  # Saturday = 5, Sunday = 6
            current_date += increment
            continue
        
        # Skip market hours outside 9:15 AM to 3:30 PM
        if interval != "daily":
            if current_date.hour < 9 or (current_date.hour == 9 and current_date.minute < 15):
                current_date += increment
                continue
            if current_date.hour >= 15 and current_date.minute > 30:
                current_date += timedelta(days=1)
                current_date = current_date.replace(hour=9, minute=15)
                continue
        
        # Generate OHLC with random walk
        change_pct = random.uniform(-0.5, 0.5) / 100  # ±0.5%
        open_price = price
        close_price = price * (1 + change_pct)
        high_price = max(open_price, close_price) * (1 + abs(random.uniform(0, 0.3) / 100))
        low_price = min(open_price, close_price) * (1 - abs(random.uniform(0, 0.3) / 100))
        
        candle = {
            "date": current_date.date(),
            "time": current_date.time(),
            "open": round(open_price, 2),
            "high": round(high_price, 2),
            "low": round(low_price, 2),
            "close": round(close_price, 2),
            "volume": random.randint(1000, 100000),
            "interval": interval,
        }
        
        candles.append(candle)
        
        price = close_price  # Continue from last close
        current_date += increment
    
    return candles
